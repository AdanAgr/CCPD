class TransThread extends Thread {
    private FinTrans ft;
    private Object lock; // Lock object shared between threads

    TransThread(FinTrans ft, String name, Object lock) {
        super(name);
        this.ft = ft;
        this.lock = lock; // Use a shared lock object
    }

    public void run() {
        for (int i = 0; i < 100; i++) {
            /*   ADD CODE:   
            *       Write the control statements and 
            *       synchronized the critical section with 
			*       "lock" to protect the Deposit and 
            *       Withdrawal threads.
            * 
            */
    }
}

class lab2prob03 {
    public static void main (String [] args)  {
	 FinTrans ft = new FinTrans();
       // Shared lock object
       Object lock = new Object();
	   TransThread tt1 = new TransThread(ft, "Deposit Thread", lock);
       TransThread tt2 = new TransThread(ft, "Withdrawal Thread", lock);
       tt1.start ();
       tt2.start ();
    }
 }