import java.util.Random;

class NewThread implements Runnable {
    String name;
    Thread t;
    Random rand = new Random();
    NewThread(String threadName) {
        name = threadName;
        t = new Thread(this, name);
        System.out.println("New thread created: " + t);
    }
    public void startThread() {
        t.start();
    }
    public void run() {
        // Simulate some CPU expensive task
        for(int i = 0; i < 100000000; i++) {
            rand.nextInt();
        }
        System.out.println("[" + Thread.currentThread().getName() + "] finished.");
    }
}


class lab1prog08 {
    public static void main(String[] args) {
        Thread[] threads = new Thread[5];
        for(int i = 0; i < threads.length; i++) {
            NewThread nt = new NewThread("joinThread-" + i);
            threads[i] = nt.t;
            nt.startThread();
        }
        for(int i = 0; i < threads.length; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                System.out.println("Thread " + threads[i].getName() + " interrupted");
            }
        }
        System.out.println("[" + Thread.currentThread().getName() + "] All threads done!");
    }
}